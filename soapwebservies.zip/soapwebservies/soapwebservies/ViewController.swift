//
//  ViewController.swift
//  soapwebservies
//
//  Created by MACOS on 11/26/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,URLSessionDelegate,XMLParserDelegate {

    var  ss:String="";
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        
        if elementName == "addResult" {
            
            print("result is\(ss) ");
        }
        
        
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
     
        ss = string
    }
    
    @IBAction func btnclick(_ sender: AnyObject) {
        
        
        let soapMessage = "<?xml version='1.0' encoding='utf-8'?><soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><add xmlns='http://tempuri.org/'><x>10</x><y>20</y></add></soap:Body></soap:Envelope>"
        
        let url = URL(string: "http://www.morningbatch.somee.com/WebService.asmx");
        
        var request = URLRequest(url: url!);
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type");
        request.addValue("http://tempuri.org/add", forHTTPHeaderField: "SOAPAction")
        request.addValue(String(soapMessage.characters.count), forHTTPHeaderField: "Content-Length");
        request.httpMethod = "POST";
        request.httpBody = soapMessage.data(using: String.Encoding.utf8)
        
        
        let session =  URLSession(configuration: URLSessionConfiguration.default, delegate: self, delegateQueue: nil);
        
        
        let task = session.dataTask(with: request) { (data1, responce, err) in
            
            let parse = XMLParser(data: data1!);
            
            parse.delegate = self
            parse.parse();
            
            
        }
    
        task.resume();
        
    }
}


